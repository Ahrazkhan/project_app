package ie.ahrazz.entity;

public record Result(String directorName, String movieName){};
