insert into Director(director_id, firstName, lastName, stillActive ) values
(1,'allan','harper',true),
(2,'ahraz','khan',true),
(3,'tom','hardy',false);

insert into movies values
(1, 'Spider-man', 2020, 150.0, 1),
(2, 'Avengers-End-game', 2019, 200.0, 1),
(3, 'The note-book', 2009, 300.0, 2),
(4, 'Wanted', 2017, 500.0, 3);